/**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 /**
 * Jangan Di Hapus!!
 *
 * Script Bot By @SaipulAnuar (ᴹᴿ᭄ King Of Bear ×፝֟͜×)
 * Youtube: https://youtu.be/pwLZpdfO8AU
 * 
 * Ingin tambah fitur tapi tidak bisa coding?
 * Ingin perbaiki fitur error tapi tidak bisa coding?
 * hubungi: https://wa.me/6288279268363
 * 
 */

 


import fetch from 'node-fetch'
import fs from 'fs'
import moment from 'moment-timezone'
let handler = async (m, { conn, args, command }) => {
  let _uptime = process.uptime() * 1000
let uptime = clockString(_uptime)
let who = m.sender
const time = moment.tz('Asia/Jakarta').format('HH')
  const ultah = new Date(`${ultahowner} 00:00:01`)
    const sekarat = new Date().getTime() 
    const Kurang = ultah - sekarat
    const ohari = Math.floor( Kurang / (1000 * 60 * 60 * 24));
    const ojam = Math.floor( Kurang % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
    const onet = Math.floor( Kurang % (1000 * 60 * 60) / (1000 * 60))
    const detek = Math.floor( Kurang % (1000 * 60) / 1000)
  let name = await conn.getName(m.sender)
  let vn = `https://github.com/saipulanuar/Api-Github/raw/main/audio/script.mp3`
  let runnya = `━━━ꕥ〔 *SOURCE CODE* 〕ꕥ━⬣
✾ *Script Private | Mau Buy? Silahkan Hubungi* https://wa.me/6288279268363
✾ *50K:* NOT FREE UPDATE
✾ *100K:* FREE UPDATE & FREE PERBAIKAN SC

✾ *OFFICIAL GROUP*
_https://chat.whatsapp.com/HAZ6yFgCafUAeDbNH33IrL_

✾ *YOUTUBE OFFICIAL*
_https://youtu.be/h8lX25IPgr4_
━━━━━━ꕥ`
  let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
 await conn.sendButton(m.chat, runnya,wm + '\n\n' + botdate, fla, [['🧑OWNER','.owner']], m, {
contextInfo: { externalAdReply :{ showAdAttribution: true,
                        sourceUrl: 'https://youtu.be/pwLZpdfO8AU',
                        mediaType: 2,
                        description: `⚘ ᴄʀᴇᴀᴛᴇ ᴹᴿ᭄ King Of Bear ×፝֟͜×`,
                        title: `💌 My Ultah: ${ohari} Hari ${ojam} Jam ${onet} Menit ${detek} Detik`,
                        body: `⚘ by ᴹᴿ᭄ King Of Bear ×፝֟͜×`,          previewType: 0,
                        thumbnail: await (await fetch(thumb)).buffer(),
                        mediaUrl: 'https://youtu.be/pwLZpdfO8AU'
                        
                      }}
})
  conn.sendFile(m.chat, vn, 'haori.mp3', null, m, true, {
type: 'audioMessage', 
ptt: true, contextInfo:{ externalAdReply: { title: `💌 Ultah Owner : ${ohari} Hari ${ojam} Jam ${onet} Menit ${detek} Detik`, body: `Follow Tiktok My Bestie`, sourceUrl: 'https://www.tiktok.com/@raraharsita2', thumbnail: await (await fetch('https://i.ibb.co/jfZVKmC/babi2.jpg')).buffer(),}} 
     })
}


handler.help = ['sc', 'sewasc']
handler.tags = ['info', 'main']

handler.command = /^(sc|script|sewasc)$/i

handler.owner = false
handler.mods = false
handler.premium = false
handler.group = true
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

export default handler 


function clockString(ms) {
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}
